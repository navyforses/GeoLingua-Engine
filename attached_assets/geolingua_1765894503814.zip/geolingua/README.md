# 🌍 GeoLingua

**P2P თარჯიმანთა მარკეტფლეისი — Bolt/Uber სტილის**

ქართველებისთვის უცხოეთში და უცხოელებისთვის საქართველოში.

---

## 🎯 რა არის GeoLingua?

GeoLingua არის პლატფორმა სადაც:
- **მომხმარებელს** შეუძლია მოითხოვოს თარჯიმანი ნებისმიერ ენაზე
- **თარჯიმანს** შეუძლია მიიღოს შეკვეთები და გამოიმუშაოს
- **AI თარჯიმანი** ხელმისაწვდომია 24/7 დაბალ ფასად

### ძირითადი ფუნქციონალი:
- 🔴 **ახლავე მჭირდება** — Broadcast სტილი, პირველი ვინც აიღებს
- 📅 **დაგეგმილი** — წინასწარ დაჯავშნა კონკრეტულ დროს
- 🤖 **AI თარჯიმანი** — იაფი ალტერნატივა მარტივი საუბრებისთვის
- 💰 **თემის მიხედვით ფასი** — ზოგადი, სამედიცინო, იურიდიული

---

## 🛠️ ტექნოლოგიური სტეკი

### Backend
- **Node.js + Express** — REST API
- **Socket.io** — რეალ-ტაიმ კომუნიკაცია
- **Supabase** — PostgreSQL მონაცემთა ბაზა
- **Twilio** — ვიდეოზარები
- **Stripe** — გადახდები
- **OpenAI** — AI თარჯიმანი (Whisper + GPT-4 + TTS)

### Frontend (მომავალი)
- **React Native** — iOS + Android
- **Expo** — სწრაფი განვითარება

---

## 📁 პროექტის სტრუქტურა

```
geolingua/
├── backend/
│   ├── config/
│   │   └── supabase.js       # Supabase კონფიგურაცია
│   ├── routes/
│   │   ├── auth.js           # რეგისტრაცია/ავტორიზაცია
│   │   ├── translators.js    # თარჯიმნების მართვა
│   │   ├── requests.js       # მოთხოვნები
│   │   ├── calls.js          # ზარები
│   │   └── payments.js       # გადახდები
│   ├── sockets/
│   │   └── handler.js        # Socket.io (Broadcast logic)
│   ├── services/
│   │   └── aiTranslator.js   # AI თარგმანი
│   ├── database/
│   │   └── schema.sql        # Supabase სქემა
│   ├── server.js             # მთავარი სერვერი
│   ├── package.json
│   └── .env.example
└── frontend/                  # (შემდეგი ეტაპი)
```

---

## 🚀 გაშვება

### 1. დააინსტალირე dependencies
```bash
cd backend
npm install
```

### 2. შექმენი .env ფაილი
```bash
cp .env.example .env
# შეავსე შენი credentials
```

### 3. გაუშვი Supabase Schema
- შედი Supabase Dashboard-ში
- SQL Editor → New Query
- ჩასვი `database/schema.sql` შიგთავსი
- Run

### 4. გაუშვი სერვერი
```bash
npm run dev
```

სერვერი გაეშვება `http://localhost:3000`

---

## 📡 API Endpoints

### Auth
| Method | Endpoint | აღწერა |
|--------|----------|--------|
| POST | `/api/auth/register` | რეგისტრაცია |
| POST | `/api/auth/login` | შესვლა |
| GET | `/api/auth/me` | მიმდინარე მომხმარებელი |

### Translators
| Method | Endpoint | აღწერა |
|--------|----------|--------|
| GET | `/api/translators/languages` | ხელმისაწვდომი ენები |
| GET | `/api/translators/categories` | კატეგორიები + ფასები |
| POST | `/api/translators/profile` | პროფილის განახლება |
| GET | `/api/translators/online` | ონლაინ თარჯიმნები |

### Requests
| Method | Endpoint | აღწერა |
|--------|----------|--------|
| POST | `/api/requests` | ახალი მოთხოვნა |
| GET | `/api/requests/user/:id` | მომხმარებლის ისტორია |
| POST | `/api/requests/:id/cancel` | გაუქმება |

### Calls
| Method | Endpoint | აღწერა |
|--------|----------|--------|
| POST | `/api/calls/token` | Twilio ტოკენი |
| POST | `/api/calls/start` | ზარის დაწყება |
| POST | `/api/calls/end` | ზარის დასრულება |
| POST | `/api/calls/:id/rate` | შეფასება |

---

## 🔌 Socket.io Events

### Client → Server
| Event | აღწერა |
|-------|--------|
| `translator:online` | თარჯიმანი ონლაინ |
| `translator:offline` | თარჯიმანი ოფლაინ |
| `user:online` | მომხმარებელი ონლაინ |
| `request:new` | ახალი მოთხოვნა (Broadcast) |
| `request:accept` | თარჯიმანი იღებს |
| `request:cancel` | გაუქმება |
| `call:start` | ზარის დაწყება |
| `call:end` | ზარის დასრულება |

### Server → Client
| Event | აღწერა |
|-------|--------|
| `request:incoming` | შემომავალი მოთხოვნა (თარჯიმანს) |
| `request:sent` | მოთხოვნა გაიგზავნა |
| `request:matched` | თარჯიმანი მოიძებნა |
| `request:taken` | შეკვეთა აიღეს |
| `request:expired` | დრო ამოიწურა |
| `call:started` | ზარი დაიწყო |
| `call:ended` | ზარი დასრულდა |

---

## 💰 ფასები

| კატეგორია | ფასი/წუთი | თარჯიმანი იღებს |
|-----------|----------|-----------------|
| 💬 ზოგადი | 2₾ | 1.4₾ (70%) |
| 📄 ადმინისტრაციული | 2.5₾ | 1.75₾ |
| 💼 ბიზნესი | 3₾ | 2.1₾ |
| 🏥 სამედიცინო | 4₾ | 2.8₾ |
| ⚖️ იურიდიული | 4₾ | 2.8₾ |
| 🤖 AI | 0.5₾ | — |

---

## 📱 Replit-ზე Deploy

1. შექმენი ახალი Repl (Node.js)
2. Import from GitHub ან ატვირთე ფაილები
3. Secrets-ში დაამატე environment variables
4. Run!

---

## 🗺️ Roadmap

### ფაზა 1 (MVP) ✅
- [x] Backend არქიტექტურა
- [x] Socket.io Broadcast
- [x] Supabase სქემა
- [x] AI თარჯიმანი სერვისი
- [ ] Frontend (React Native)

### ფაზა 2
- [ ] Push notifications
- [ ] პირადი შეხვედრები (GPS)
- [ ] თარჯიმნის dashboard
- [ ] Analytics

### ფაზა 3
- [ ] iOS App Store
- [ ] Google Play
- [ ] Web app
- [ ] B2B პაკეტები

---

## 📞 კონტაქტი

GeoLingua — შექმნილია ❤️-ით ქართველებისთვის

---

*Version 1.0.0 | December 2024*
